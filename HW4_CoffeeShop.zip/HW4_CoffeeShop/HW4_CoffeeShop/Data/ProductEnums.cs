﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW4_CoffeeShop.Data
{
    public enum DrinkCategories
    {
        None,
        Coffee,
        HotDrink,
        ColdDrink,
    }

    public enum CupSize
    {
        Small,
        Medium,
        Big,
    }

    public enum Milk
    {
        None,
        Skimmed,
        Soya,

    }
}