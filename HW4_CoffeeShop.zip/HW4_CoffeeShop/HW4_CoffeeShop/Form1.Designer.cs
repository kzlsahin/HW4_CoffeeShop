﻿namespace HW4_CoffeeShop
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.GroupPrdouts = new System.Windows.Forms.GroupBox();
            this.GroupExtras = new System.Windows.Forms.GroupBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.radioButtonSizeBig = new System.Windows.Forms.RadioButton();
            this.radioButtonSizeMedium = new System.Windows.Forms.RadioButton();
            this.radioButtonSizeSmall = new System.Windows.Forms.RadioButton();
            this.labelCupSize = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.RadioButtonFatSoya = new System.Windows.Forms.RadioButton();
            this.RadioButtonFatless = new System.Windows.Forms.RadioButton();
            this.labelMilk = new System.Windows.Forms.Label();
            this.CheckBoxTwoShot = new System.Windows.Forms.CheckBox();
            this.CheckBoxOneShot = new System.Windows.Forms.CheckBox();
            this.labelShot = new System.Windows.Forms.Label();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.comboBoxHotDrinks = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.comboBoxColdDrinks = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.comboBoxCoffees = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.BtnCalculate = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.TextBoxAddress = new System.Windows.Forms.TextBox();
            this.labelAddress = new System.Windows.Forms.Label();
            this.TextBoxPhone = new System.Windows.Forms.TextBox();
            this.labelPhone = new System.Windows.Forms.Label();
            this.TextBoxUserName = new System.Windows.Forms.TextBox();
            this.LabelUserName = new System.Windows.Forms.Label();
            this.BtnGiveOrder = new System.Windows.Forms.Button();
            this.LabelTotalAmount = new System.Windows.Forms.Label();
            this.GroupOrders = new System.Windows.Forms.GroupBox();
            this.ListBoxSelectedProducts = new System.Windows.Forms.ListBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.GroupPrdouts.SuspendLayout();
            this.GroupExtras.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.GroupOrders.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(939, 93);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(242, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(96, 87);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(334, 27);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(357, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "Bilge kahve Evi Sipariş Ekranı";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 93);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.GroupPrdouts);
            this.splitContainer1.Panel1.Controls.Add(this.groupBox1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.BtnGiveOrder);
            this.splitContainer1.Panel2.Controls.Add(this.LabelTotalAmount);
            this.splitContainer1.Panel2.Controls.Add(this.GroupOrders);
            this.splitContainer1.Size = new System.Drawing.Size(939, 543);
            this.splitContainer1.SplitterDistance = 477;
            this.splitContainer1.TabIndex = 1;
            // 
            // GroupPrdouts
            // 
            this.GroupPrdouts.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GroupPrdouts.Controls.Add(this.GroupExtras);
            this.GroupPrdouts.Controls.Add(this.numericUpDown3);
            this.GroupPrdouts.Controls.Add(this.comboBoxHotDrinks);
            this.GroupPrdouts.Controls.Add(this.label7);
            this.GroupPrdouts.Controls.Add(this.numericUpDown2);
            this.GroupPrdouts.Controls.Add(this.comboBoxColdDrinks);
            this.GroupPrdouts.Controls.Add(this.label6);
            this.GroupPrdouts.Controls.Add(this.label5);
            this.GroupPrdouts.Controls.Add(this.numericUpDown1);
            this.GroupPrdouts.Controls.Add(this.comboBoxCoffees);
            this.GroupPrdouts.Controls.Add(this.label4);
            this.GroupPrdouts.Controls.Add(this.BtnCalculate);
            this.GroupPrdouts.Location = new System.Drawing.Point(12, 203);
            this.GroupPrdouts.Name = "GroupPrdouts";
            this.GroupPrdouts.Size = new System.Drawing.Size(450, 328);
            this.GroupPrdouts.TabIndex = 1;
            this.GroupPrdouts.TabStop = false;
            this.GroupPrdouts.Text = "Ürünler";
            // 
            // GroupExtras
            // 
            this.GroupExtras.Controls.Add(this.panel3);
            this.GroupExtras.Controls.Add(this.panel2);
            this.GroupExtras.Controls.Add(this.CheckBoxTwoShot);
            this.GroupExtras.Controls.Add(this.CheckBoxOneShot);
            this.GroupExtras.Controls.Add(this.labelShot);
            this.GroupExtras.Location = new System.Drawing.Point(8, 158);
            this.GroupExtras.Name = "GroupExtras";
            this.GroupExtras.Size = new System.Drawing.Size(430, 128);
            this.GroupExtras.TabIndex = 11;
            this.GroupExtras.TabStop = false;
            this.GroupExtras.Text = "Ekstralar";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.radioButtonSizeBig);
            this.panel3.Controls.Add(this.radioButtonSizeMedium);
            this.panel3.Controls.Add(this.radioButtonSizeSmall);
            this.panel3.Controls.Add(this.labelCupSize);
            this.panel3.Location = new System.Drawing.Point(12, 82);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(419, 27);
            this.panel3.TabIndex = 12;
            // 
            // radioButtonSizeBig
            // 
            this.radioButtonSizeBig.AutoSize = true;
            this.radioButtonSizeBig.Location = new System.Drawing.Point(359, 5);
            this.radioButtonSizeBig.Name = "radioButtonSizeBig";
            this.radioButtonSizeBig.Size = new System.Drawing.Size(58, 19);
            this.radioButtonSizeBig.TabIndex = 14;
            this.radioButtonSizeBig.TabStop = true;
            this.radioButtonSizeBig.Text = "Büyük";
            this.radioButtonSizeBig.UseVisualStyleBackColor = true;
            this.radioButtonSizeBig.CheckedChanged += new System.EventHandler(this.radioButtonSizeBig_CheckedChanged);
            // 
            // radioButtonSizeMedium
            // 
            this.radioButtonSizeMedium.AutoSize = true;
            this.radioButtonSizeMedium.Location = new System.Drawing.Point(255, 5);
            this.radioButtonSizeMedium.Name = "radioButtonSizeMedium";
            this.radioButtonSizeMedium.Size = new System.Drawing.Size(48, 19);
            this.radioButtonSizeMedium.TabIndex = 13;
            this.radioButtonSizeMedium.TabStop = true;
            this.radioButtonSizeMedium.Text = "Orta";
            this.radioButtonSizeMedium.UseVisualStyleBackColor = true;
            this.radioButtonSizeMedium.CheckedChanged += new System.EventHandler(this.radioButtonSizeMedium_CheckedChanged);
            // 
            // radioButtonSizeSmall
            // 
            this.radioButtonSizeSmall.AutoSize = true;
            this.radioButtonSizeSmall.Location = new System.Drawing.Point(148, 5);
            this.radioButtonSizeSmall.Name = "radioButtonSizeSmall";
            this.radioButtonSizeSmall.Size = new System.Drawing.Size(58, 19);
            this.radioButtonSizeSmall.TabIndex = 12;
            this.radioButtonSizeSmall.TabStop = true;
            this.radioButtonSizeSmall.Text = "Küçük";
            this.radioButtonSizeSmall.UseVisualStyleBackColor = true;
            this.radioButtonSizeSmall.CheckedChanged += new System.EventHandler(this.radioButtonSizeSmall_CheckedChanged);
            // 
            // labelCupSize
            // 
            this.labelCupSize.AutoSize = true;
            this.labelCupSize.Location = new System.Drawing.Point(19, 7);
            this.labelCupSize.Name = "labelCupSize";
            this.labelCupSize.Size = new System.Drawing.Size(90, 15);
            this.labelCupSize.TabIndex = 11;
            this.labelCupSize.Text = "İçecek  Boyutu :";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.RadioButtonFatSoya);
            this.panel2.Controls.Add(this.RadioButtonFatless);
            this.panel2.Controls.Add(this.labelMilk);
            this.panel2.Location = new System.Drawing.Point(12, 49);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(419, 27);
            this.panel2.TabIndex = 11;
            // 
            // RadioButtonFatSoya
            // 
            this.RadioButtonFatSoya.AutoSize = true;
            this.RadioButtonFatSoya.Location = new System.Drawing.Point(255, 3);
            this.RadioButtonFatSoya.Name = "RadioButtonFatSoya";
            this.RadioButtonFatSoya.Size = new System.Drawing.Size(50, 19);
            this.RadioButtonFatSoya.TabIndex = 9;
            this.RadioButtonFatSoya.TabStop = true;
            this.RadioButtonFatSoya.Text = "Soya";
            this.RadioButtonFatSoya.UseVisualStyleBackColor = true;
            this.RadioButtonFatSoya.CheckedChanged += new System.EventHandler(this.RadioButtonFatSoya_CheckedChanged);
            // 
            // RadioButtonFatless
            // 
            this.RadioButtonFatless.AutoSize = true;
            this.RadioButtonFatless.Location = new System.Drawing.Point(148, 3);
            this.RadioButtonFatless.Name = "RadioButtonFatless";
            this.RadioButtonFatless.Size = new System.Drawing.Size(57, 19);
            this.RadioButtonFatless.TabIndex = 8;
            this.RadioButtonFatless.TabStop = true;
            this.RadioButtonFatless.Text = "Yağsız";
            this.RadioButtonFatless.UseVisualStyleBackColor = true;
            this.RadioButtonFatless.CheckedChanged += new System.EventHandler(this.RadioButtonFatless_CheckedChanged);
            // 
            // labelMilk
            // 
            this.labelMilk.AutoSize = true;
            this.labelMilk.Location = new System.Drawing.Point(18, 7);
            this.labelMilk.Name = "labelMilk";
            this.labelMilk.Size = new System.Drawing.Size(30, 15);
            this.labelMilk.TabIndex = 7;
            this.labelMilk.Text = "Süt :";
            // 
            // CheckBoxTwoShot
            // 
            this.CheckBoxTwoShot.AutoSize = true;
            this.CheckBoxTwoShot.Location = new System.Drawing.Point(223, 23);
            this.CheckBoxTwoShot.Name = "CheckBoxTwoShot";
            this.CheckBoxTwoShot.Size = new System.Drawing.Size(38, 19);
            this.CheckBoxTwoShot.TabIndex = 4;
            this.CheckBoxTwoShot.Text = "2x";
            this.CheckBoxTwoShot.UseVisualStyleBackColor = true;
            this.CheckBoxTwoShot.CheckedChanged += new System.EventHandler(this.CheckBoxTwoShot_CheckedChanged);
            // 
            // CheckBoxOneShot
            // 
            this.CheckBoxOneShot.AutoSize = true;
            this.CheckBoxOneShot.Location = new System.Drawing.Point(154, 24);
            this.CheckBoxOneShot.Name = "CheckBoxOneShot";
            this.CheckBoxOneShot.Size = new System.Drawing.Size(38, 19);
            this.CheckBoxOneShot.TabIndex = 3;
            this.CheckBoxOneShot.Text = "1x";
            this.CheckBoxOneShot.UseVisualStyleBackColor = true;
            this.CheckBoxOneShot.CheckedChanged += new System.EventHandler(this.CheckBoxOneShot_CheckedChanged);
            // 
            // labelShot
            // 
            this.labelShot.AutoSize = true;
            this.labelShot.Location = new System.Drawing.Point(24, 28);
            this.labelShot.Name = "labelShot";
            this.labelShot.Size = new System.Drawing.Size(37, 15);
            this.labelShot.TabIndex = 0;
            this.labelShot.Text = "Shot :";
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.Location = new System.Drawing.Point(396, 124);
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(43, 23);
            this.numericUpDown3.TabIndex = 10;
            // 
            // comboBoxHotDrinks
            // 
            this.comboBoxHotDrinks.FormattingEnabled = true;
            this.comboBoxHotDrinks.Location = new System.Drawing.Point(149, 124);
            this.comboBoxHotDrinks.Name = "comboBoxHotDrinks";
            this.comboBoxHotDrinks.Size = new System.Drawing.Size(232, 23);
            this.comboBoxHotDrinks.TabIndex = 9;
            this.comboBoxHotDrinks.SelectedIndexChanged += new System.EventHandler(this.DrinkComboboxes_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(48, 126);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(101, 15);
            this.label7.TabIndex = 8;
            this.label7.Text = "Sıcak İçeçecekler :";
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Location = new System.Drawing.Point(396, 81);
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(43, 23);
            this.numericUpDown2.TabIndex = 7;
            // 
            // comboBoxColdDrinks
            // 
            this.comboBoxColdDrinks.FormattingEnabled = true;
            this.comboBoxColdDrinks.Location = new System.Drawing.Point(149, 81);
            this.comboBoxColdDrinks.Name = "comboBoxColdDrinks";
            this.comboBoxColdDrinks.Size = new System.Drawing.Size(232, 23);
            this.comboBoxColdDrinks.TabIndex = 6;
            this.comboBoxColdDrinks.SelectedIndexChanged += new System.EventHandler(this.DrinkComboboxes_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(48, 83);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(95, 15);
            this.label6.TabIndex = 5;
            this.label6.Text = "Soğuk İçecekler :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(396, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(32, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "Adet";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(396, 38);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(43, 23);
            this.numericUpDown1.TabIndex = 3;
            // 
            // comboBoxCoffees
            // 
            this.comboBoxCoffees.FormattingEnabled = true;
            this.comboBoxCoffees.Location = new System.Drawing.Point(149, 38);
            this.comboBoxCoffees.Name = "comboBoxCoffees";
            this.comboBoxCoffees.Size = new System.Drawing.Size(232, 23);
            this.comboBoxCoffees.TabIndex = 2;
            this.comboBoxCoffees.SelectedIndexChanged += new System.EventHandler(this.DrinkComboboxes_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(48, 46);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 15);
            this.label4.TabIndex = 1;
            this.label4.Text = "Kahveler :";
            // 
            // BtnCalculate
            // 
            this.BtnCalculate.Location = new System.Drawing.Point(8, 293);
            this.BtnCalculate.Name = "BtnCalculate";
            this.BtnCalculate.Size = new System.Drawing.Size(437, 30);
            this.BtnCalculate.TabIndex = 0;
            this.BtnCalculate.Text = "Hesapla";
            this.BtnCalculate.UseVisualStyleBackColor = true;
            this.BtnCalculate.Click += new System.EventHandler(this.BtnCalculate_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.TextBoxAddress);
            this.groupBox1.Controls.Add(this.labelAddress);
            this.groupBox1.Controls.Add(this.TextBoxPhone);
            this.groupBox1.Controls.Add(this.labelPhone);
            this.groupBox1.Controls.Add(this.TextBoxUserName);
            this.groupBox1.Controls.Add(this.LabelUserName);
            this.groupBox1.Location = new System.Drawing.Point(14, 14);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(448, 180);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Müşteri Bilgileri";
            // 
            // TextBoxAddress
            // 
            this.TextBoxAddress.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TextBoxAddress.Location = new System.Drawing.Point(116, 83);
            this.TextBoxAddress.Multiline = true;
            this.TextBoxAddress.Name = "TextBoxAddress";
            this.TextBoxAddress.Size = new System.Drawing.Size(305, 88);
            this.TextBoxAddress.TabIndex = 5;
            // 
            // labelAddress
            // 
            this.labelAddress.AutoSize = true;
            this.labelAddress.Location = new System.Drawing.Point(5, 86);
            this.labelAddress.Name = "labelAddress";
            this.labelAddress.Size = new System.Drawing.Size(48, 15);
            this.labelAddress.TabIndex = 4;
            this.labelAddress.Text = "Adress :";
            // 
            // TextBoxPhone
            // 
            this.TextBoxPhone.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TextBoxPhone.Location = new System.Drawing.Point(116, 53);
            this.TextBoxPhone.Name = "TextBoxPhone";
            this.TextBoxPhone.Size = new System.Drawing.Size(305, 23);
            this.TextBoxPhone.TabIndex = 3;
            // 
            // labelPhone
            // 
            this.labelPhone.AutoSize = true;
            this.labelPhone.Location = new System.Drawing.Point(5, 56);
            this.labelPhone.Name = "labelPhone";
            this.labelPhone.Size = new System.Drawing.Size(51, 15);
            this.labelPhone.TabIndex = 2;
            this.labelPhone.Text = "Telefon :";
            // 
            // TextBoxUserName
            // 
            this.TextBoxUserName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TextBoxUserName.Location = new System.Drawing.Point(116, 24);
            this.TextBoxUserName.Name = "TextBoxUserName";
            this.TextBoxUserName.Size = new System.Drawing.Size(305, 23);
            this.TextBoxUserName.TabIndex = 1;
            // 
            // LabelUserName
            // 
            this.LabelUserName.AutoSize = true;
            this.LabelUserName.Location = new System.Drawing.Point(5, 27);
            this.LabelUserName.Name = "LabelUserName";
            this.LabelUserName.Size = new System.Drawing.Size(63, 15);
            this.LabelUserName.TabIndex = 0;
            this.LabelUserName.Text = "Ad Soyad :";
            // 
            // BtnGiveOrder
            // 
            this.BtnGiveOrder.Location = new System.Drawing.Point(9, 496);
            this.BtnGiveOrder.Name = "BtnGiveOrder";
            this.BtnGiveOrder.Size = new System.Drawing.Size(437, 30);
            this.BtnGiveOrder.TabIndex = 2;
            this.BtnGiveOrder.Text = "Sipariş Ver";
            this.BtnGiveOrder.UseVisualStyleBackColor = true;
            this.BtnGiveOrder.Click += new System.EventHandler(this.BtnGiveOrder_Click);
            // 
            // LabelTotalAmount
            // 
            this.LabelTotalAmount.AutoSize = true;
            this.LabelTotalAmount.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LabelTotalAmount.Location = new System.Drawing.Point(10, 458);
            this.LabelTotalAmount.Name = "LabelTotalAmount";
            this.LabelTotalAmount.Size = new System.Drawing.Size(392, 30);
            this.LabelTotalAmount.TabIndex = 1;
            this.LabelTotalAmount.Text = "Toplam Sipariş Tutarı : --------        TL";
            // 
            // GroupOrders
            // 
            this.GroupOrders.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GroupOrders.Controls.Add(this.ListBoxSelectedProducts);
            this.GroupOrders.Location = new System.Drawing.Point(10, 14);
            this.GroupOrders.Name = "GroupOrders";
            this.GroupOrders.Size = new System.Drawing.Size(436, 441);
            this.GroupOrders.TabIndex = 0;
            this.GroupOrders.TabStop = false;
            this.GroupOrders.Text = "Siparişler";
            // 
            // ListBoxSelectedProducts
            // 
            this.ListBoxSelectedProducts.FormattingEnabled = true;
            this.ListBoxSelectedProducts.ItemHeight = 15;
            this.ListBoxSelectedProducts.Location = new System.Drawing.Point(7, 23);
            this.ListBoxSelectedProducts.Name = "ListBoxSelectedProducts";
            this.ListBoxSelectedProducts.Size = new System.Drawing.Size(422, 394);
            this.ListBoxSelectedProducts.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(939, 636);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.GroupPrdouts.ResumeLayout(false);
            this.GroupPrdouts.PerformLayout();
            this.GroupExtras.ResumeLayout(false);
            this.GroupExtras.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.GroupOrders.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Panel panel1;
        private Label label1;
        private PictureBox pictureBox1;
        private SplitContainer splitContainer1;
        private GroupBox groupBox1;
        private GroupBox GroupPrdouts;
        private TextBox TextBoxUserName;
        private Label LabelUserName;
        private Label LabelTotalAmount;
        private GroupBox GroupOrders;
        private GroupBox GroupExtras;
        private Label labelShot;
        private NumericUpDown numericUpDown3;
        private ComboBox comboBoxHotDrinks;
        private Label label7;
        private NumericUpDown numericUpDown2;
        private ComboBox comboBoxColdDrinks;
        private Label label6;
        private Label label5;
        private NumericUpDown numericUpDown1;
        private ComboBox comboBoxCoffees;
        private Label label4;
        private Button BtnCalculate;
        private TextBox TextBoxAddress;
        private Label labelAddress;
        private TextBox TextBoxPhone;
        private Label labelPhone;
        private Button BtnGiveOrder;
        private CheckBox CheckBoxTwoShot;
        private CheckBox CheckBoxOneShot;
        private ListBox ListBoxSelectedProducts;
        private Panel panel3;
        private RadioButton radioButtonSizeBig;
        private RadioButton radioButtonSizeMedium;
        private RadioButton radioButtonSizeSmall;
        private Label labelCupSize;
        private Panel panel2;
        private RadioButton RadioButtonFatSoya;
        private RadioButton RadioButtonFatless;
        private Label labelMilk;
    }
}